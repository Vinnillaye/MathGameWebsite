<header>
<h1 style="color:blue;">Welcome To Math Adventure Dome</h1>
        
        <div class="navbar">
        <a href="TeacherView.php">Home</a>
        <a href="addition.php">Addition Game</a>
        <a href="subtraction.php">Subtraction Game</a>
        <a href="digMenuTeacher.php">Number Place Game</a>
        <div class="dropdown">
            <button class="dropbtn">More
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href=studentList.php>View Students</a>
                <a href=customQuestions.php>Create Custom Questions</a>
                <a href=passwordReset.php>Student Password Reset</a>
                <a href=contactUs.php>Contact Us</a>
                
            </div>
        </div>
        <div class="topnav-right">
            <div class="dropdown">
            <button class="dropbtn"><?php echo $_SESSION['uname'];?>
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href=profile.php>View Profile</a>
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
</header>