<!DOCTYPE html>

	<head>
		<meta charset="UTF-8">
		<title> Math Adventure Dome</title>
	</head> 
    <link rel="stylesheet" href="navBar.css">
	<style type="text/css">
            body {background: -webkit-linear-gradient(left, #690534, #271d22);}
			body{
				font-family: Monaco;
			}  
}  
	</style>
	<body>
        <?php 
            
			include_once "my_functions.php";
			my_session_start();
			if(isset($_SESSION['uname'])){	
			}else{
				header("Location: login.php");
            }
            include("headerTeacher.php");
		?>
        
            <!-- <a href="scoreboard.php">Scoreboard</a> -->
</html>
</body>
</html>