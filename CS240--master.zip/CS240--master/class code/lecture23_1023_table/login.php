<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login</title>
</head>
<body>
	<?php
		include_once "my_functions.php";
		my_session_start();
		if(isset($_SESSION['uname'])){
			header("Location: welcome.php");
		}	
	?>
	<form action="check_login.php" method="post" id="form_id">
		<h2>Welcome to Math Game</h2>
		Userame:
		<input type="text" name="username" id="username" placeholder="Name" />
		<br><br>
		Password:
		<input type="password" name="pw" id="password" placeholder="Password" />
		<input type="submit" name="action_name" id="login" value="login" />
	</form>

</body>
</html>