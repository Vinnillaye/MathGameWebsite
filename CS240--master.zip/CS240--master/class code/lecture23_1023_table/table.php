<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{
            margin: 0;
            padding: 0;
        }

        .user_info, td, th{
            /** sets whether table borders should collapse into 
            a single border or be separated 
            separate/collapse
            */
            border-collapse:collapse;
            border: 2px solid tomato;
            /**sets the horizontal alignment of the content in <th> or <td> */
            text-align: left;
            margin-left: 10px;
        }
        td, th{
            padding: 5px 5px 5px 10px;
        }

        img{
            width: 45px;
            vertical-align: middle;
        }

        a{
            text-decoration: none;
            vertical-align: middle;
        }

    </style>
</head>
<body>
    <!-- <div style="padding-bottom:5px; margin-left: 10px; margin-top:10px;">Students list:</div> -->
    <table class="user_info">
        <thead>
            <th>
                Name
            </th>
            <th>
                Email
            </th>
        </thead>
        <tbody>   
            <?php
            #echo "<pre>";
                include_once "fileIO.php";
                $info_arr = getData(USERFILE);
                #print_r($info_arr);
            foreach($info_arr as $k => $v){
                extract($v);
                echo "
                <tr>
                    <td>
                    <img src='$img_url'>
                      <a href='login.php' target= '_blank'>$name</a>
                    </td>
                    <td>$email</td>
                </tr>";
            }
                
        
            ?>

        </tbody>
    
    </table>

</body>
</html>