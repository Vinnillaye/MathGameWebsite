
<header>
<h1 style="color:blue;">Welcome To Math Adventure Dome</h1>

<div class="navbar">
    <a href="home.php">Home</a>
    <a href="addition.php">Addition Game</a>
    <a href="subtraction.php">Subtraction Game</a>
    <a href="digMenuStudent.php">Number Place Game</a>
    <div class="dropdown">
        <button class="dropbtn">
            More
            <i class="fa fa-caret-down"></i>
        </button>
        <div class="dropdown-content">
            <a href=passwordReset.php>Reset Password</a>
            <a href=contactUs.php>Contact Us</a>

        </div>
    </div>
    <div class="topnav-right">
        <div class="dropdown">
            <button class="dropbtn">
                <?php echo $_SESSION['uname'];?>
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content">
                <a href=profile.php>View Profile</a>
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div> 
</div>
</header>
