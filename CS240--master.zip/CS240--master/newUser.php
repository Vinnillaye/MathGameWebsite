<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>New User</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    <?php
        require 'database.php';
        include_once "my_functions.php";
        my_session_start();
        if (isset($_SESSION['uname']) && isset($_SESSION["isTeacher"])) {
            if ($_SESSION["isTeacher"] == true){
                header("Location: TeacherView.php");
            } else {
                header("Location: home.php");
            }
        }

        init_database();

        if(isset($_GET['username']) && isset($_GET['password']) && isset($_GET['teacher'])){
            $username = $_GET['username'];
            $password = $_GET['password'];
            $teacher = $_GET['teacher'];
            if(get_user($username) == null && get_teacher($teacher) != null){
                $_SESSION['uname'] = $username;
                add_user($username, $password, $teacher);
                header("Location: login.php");
                $_POST['username'] = "";
                $_POST['password'] = "";
                $_POST['teacher'] = "";
            }else{
                if(get_user($username)!= null){
                    echo '<script> console.log("in") </script>';
                    echo '<script> alert("User already exists") </script>';
                }
                else if(get_teacher($teacher)  == null){
                    echo '<script> alert("Teacher does not exist") </script>';
                }
                
            }
            
            
        }

    ?>
</head>

<body>
    <div id="login-box">
        <!-- This is so i can style -->
        <form action="newUser.php" method="GET">
            <h1>Create A New Account</h1>
            <div id="newUsername-box">
                <label for="username">Username:<label>
                        <!-- the text itself -->
                        <input type="text" id="username-box" name="username" placeholder="Username" /> <!-- type is text we you can type in the box -->
            </div>
            <br>
            <div id="newPassword-box">
                <label for="password">Password:</label> <!-- The text itself -->
                <input type="password" id="password-box" name="password" placeholder="Password" /> <!-- Type is password so letters are starred -->
            </div>
            <br /><br />
            <label for="teacher">Teacher:<label>
                    <input type="text" name="teacher" id="Teacher-class" placeholder="Teacher" />
                    <div id="createUser-button">
                        <button type="submit" id= "newUser-button" method="POST">Create</button>
                    </div>
        </form>
        <a href="login.php">Back to Login</a> <br>

        <!--- its currently a hyperlink as the button fucks with submitting with the java script above -->
        <!-- <button type="submit" onclick = "login.php" id="login-button" >Back to Login</button> -->
        
    </div>
</body>

</html>