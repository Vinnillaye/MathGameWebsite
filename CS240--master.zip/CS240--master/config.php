<?php
define('USERFILE', 'DB/user.json');
define('INACTIVEUSER', 0);
define('ACTIVEUSER', 1);
