<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <?php

        require 'database.php';
        include_once "my_functions.php";
        my_session_start();
        if (isset($_SESSION['uname']) && isset($_SESSION["isTeacher"])) {
            if ($_SESSION["isTeacher"] == true){
                header("Location: TeacherView.php");
            } else {
                header("Location: home.php");
            }
        }

 


        init_database();

        if(isset($_GET['username']) && isset($_GET['password'])){
            $username = $_GET['username'];
            $password = $_GET['password'];
            if(is_login_valid_user($username, $password)){
                $_SESSION['uname'] = $username;
                $_SESSION['isTeacher'] = false;
                header("Location: home.php");
                $_POST['username'] = "";
                $_POST['password'] = "";
            }
            else{
                echo '<script> alert("Username and password invalid") </script>';
            }
            
            
        }
    ?>

</head>

<body>

    <!--<form action="check_login.php" method="post" id="form_id"> -->

    <div id="login-box">
    <h1>Student Login</h1>

        <form action="login.php" method="GET">
            <label for="username">Username:</label>
            <input type="text" id="username-box" name="username"><br><br>
            <label for="password">Password:</label>
            <input type="text" id="password-box" name="password"><br><br>
            <button type="submit" id="login-button" method="POST">Submit</button>
        </form>


        <a href="teacher-login.php">Teacher Login</a> <br>
        <a href="newUser.php">New User?</a>
    </div>
    </div>
</body>

</html>