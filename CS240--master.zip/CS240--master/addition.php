<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addition Game</title>
</head>
<body>
   <?php
        include_once "my_functions.php";
        my_session_start();
        if(isset($_SESSION['uname'])){
            echo $_SESSION['uname'].", do you want to play a game?";
        }else{
            header("Location: login.php");
        }
   ?>
   <div>
        <a href="my_functions.php?method=logout">Logout</a>
   </div>
   
</body>
</html>