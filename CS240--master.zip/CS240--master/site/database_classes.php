<?php
//this file contains all the classes for the database


//the user class stores all the data for a user
class user{

    private $username = "";
    private $password = "";
    private $teacher = "";

    function __construct($username, $password, $teacher)
    {
        //init variables
        $this->username = $username; //username
        $this->password = $password;  //user's password
        $this->teacher = $teacher;  //user's teacher's username
    }

    //get the username
    public function get_username(){
        return $this->username;
    }

    //get the teacher's username
    public function get_teacher(){ 
        return $this->teacher;
    }

    //returns true if the given password matches
    public function is_valid_password($pass_in){
        return $pass_in == $this->password;
    }
}


//the teacher class stores all the data for a teacher
class teacher{

    private $username = "";
    private $password = "";
    private $students = [];

    //students is a list of usernames
    function __construct($username, $password, $students)
    {
        //init variables
        $this->username = $username; //username
        $this->password = $password;  //user's password
        $this->students = $students;  //teacher's student's usernames
    }

    //get the username
    public function get_username(){
        return  $this->username;
    }

    //get the teacher's students -- returns a list of user names
    public function get_students(){ 
        return  $this->students;
    }

    //returns true if the given password matches
    public function is_valid_password($pass_in){
        return $pass_in ==  $this->password;
    }



    //creates the level folder if it dosen't exist
    private function validate_level_folder(){
        if(!is_dir("teacher_levels/".$this->username)){
            mkdir("teacher_levels/".$this->username);
        }
    }

    //saves a json level to the teacher
    //returns false if the level did not save
    public function save_level_json($level_name, $json_string){
        $this->validate_level_folder();
        if(file_exists("teacher_levels/".$this->username."/".$level_name.".json")){
            return false;
        }
        else{
            $new_level_file = fopen("teacher_levels/".$this->username."/".$level_name.".json","w");
            fwrite($new_level_file, $json_string);
            fclose($new_level_file);
        }

        
    }

    //loads a json level from the teacher
    //returns an empty string if the level could not be loaded
    public function load_level_json($level_name){
        $this->validate_level_folder();
        if(!file_exists("teacher_levels/".$this->username."/".$level_name.".json")){
            return "";
        }
        else{
            $level_file = fopen("teacher_levels/".$this->username."/".$level_name.".json","r");
            $to_return = fread($level_file, filesize("teacher_levels/".$this->username."/".$level_name.".json"));
            fclose($level_file);
            return $to_return;
        }
    }

    //returns an array of all the json levels in the teacher
    public function get_levels_json(){
        $this->validate_level_folder();
        $files = scandir("teacher_levels/".$this->username);
        $json_files = array();
        foreach($files as &$file){
            $ext = pathinfo($file, PATHINFO_EXTENSION);
            if($ext = "json"){
                $name = substr($file, 0, -5);
                if($name != ""){
                    array_push($json_files, $name);
                }
                
                
            }
        }

        return $json_files;
        
    }

    
}
?>