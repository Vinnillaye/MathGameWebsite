<?php
require 'database_classes.php';

//define constants
define("DATABASE_LOCATION", "database.sqlite");

//the column names for the user table
define("USER_USERNAME_COLUMN", "username");
define("USER_PASSWORD_COLUMN", "password");
define("USER_TEACHER", "teacher");

//the column names for the teacher table
define("TEACHER_USERNAME_COLUMN", "username");
define("TEACHER_PASSWORD_COLUMN", "password");
define("TEACHER_STUDENTS", "students");

$GLOBALS["database"] = null;

//initializes the database
function init_database()
{

    //if database file dosen't exist. create one
    if (!file_exists(constant("DATABASE_LOCATION"))) {
        $database_file = fopen(constant("DATABASE_LOCATION"), "w");
        fclose($database_file);
    }

    //initialize the database class
    $database = new SQLite3(constant("DATABASE_LOCATION"));
    $GLOBALS["database"] = $database;

    //setup database file if empty. adds the correct data 
    //add the users table. has username, password and teacher columns
    $database->exec('CREATE TABLE IF NOT EXISTS users ('.constant("USER_USERNAME_COLUMN").' 
    varchar(255),'.constant("USER_PASSWORD_COLUMN").' varchar(255),'. constant("USER_TEACHER").' varchar(255))');

    //add the teachers use table. has username,password and students columns
    $database->exec('CREATE TABLE IF NOT EXISTS teachers ('.constant("TEACHER_USERNAME_COLUMN").' 
    varchar(255),'.constant("TEACHER_PASSWORD_COLUMN").' varchar(255),'. constant("TEACHER_STUDENTS").' varchar(255))');
}

//start the init of the database
init_database();

//adds a user to the database
function add_user($username, $password, $teacher){
    $column_arr = array(constant("USER_USERNAME_COLUMN"), constant("USER_PASSWORD_COLUMN"), constant("USER_TEACHER"));
    $data_arr = array($username, $password, $teacher);
    add_to_database('users', $column_arr, $data_arr);
}

//adds a teacher to the database
function add_teacher($username, $password, $students){
    $column_arr = array(constant("TEACHER_USERNAME_COLUMN"), constant("TEACHER_PASSWORD_COLUMN"), constant("TEACHER_STUDENTS"));
    $data_arr = array($username, $password, $students);
    add_to_database('teachers', $column_arr, $data_arr);
}

//adds the given item into the database
//takes table name, a list of columns and a list of data - must be the same size
//returns true if succeeded or false if failed
function add_to_database($table_name, $columns, $data){
    if(count($columns) != count($data)){ //if arrays are not the same length - fail to add
        return false;
    }else{ //otherwise try to add the data
        $database= $GLOBALS["database"];
        $column_segment = "(".implode(",", $columns).")";
        $quote_elements_func = function ($e) {return "'".$e."'";};
        $data_segment = "(".implode(",", array_map($quote_elements_func, $data)).")";
        $database->exec('INSERT INTO '.$table_name. ' ' . $column_segment . ' VALUES'.$data_segment);
        return true;
    }
}




//gets a user from the database
//returns null if the user cannot be found
function get_user($username){
    $dataArr = get_from_database("users", constant('USER_USERNAME_COLUMN'), $username);
    if($dataArr == null){
        return null;
    }
    return new user($dataArr[0], $dataArr[1], $dataArr[2]);
}

//gets a user from the database
//returns null if the user cannot be found
function get_teacher($username){
    $dataArr = get_from_database("teachers", constant('TEACHER_USERNAME_COLUMN'), $username);
    if($dataArr == null){
        return null;
    }
    return new teacher($dataArr[0], $dataArr[1], $dataArr[2]);
}


//data from a table where the given column matches the given phrase
function get_from_database($table, $column, $phrase){
    try{
        $database= $GLOBALS["database"];
        $results = $database->query("SELECT * FROM ".$table." WHERE ".$table.".".$column."='".$phrase."'");
 
        $dataArr = [];
        if ($row = $results->fetchArray()) {

            
            $counter = 0;
            foreach($row as &$value){ //values come out as duplicates to we have to filter those out
               if($counter == 0){
                   array_push($dataArr, $value);
                   $counter += 1;
               }
               else{
                   $counter = 0;
               }
           }


        return $dataArr; 
        }
        else{
            return null;
        }


       

    } catch (Exception $e){
        return null;

    }
}

//returns true if the user and password are valid else returns false
function is_login_valid_user($username, $password){
    $user = get_user($username);
    if($user == null){
        return false;
    }
    else{
        return $user->is_valid_password($password);
    }
}

//returns true if the user and password are valid else returns false for teacher
function is_login_valid_teacher($username, $password){
    $teacher = get_teacher($username);
    if($teacher == null){
        return false;
    }
    else{
        return $teacher->is_valid_password($password);
    }
}




