<!DOCTYPE html>
<html>
<body>
	<form action="Login.php" method="post" id="form_id">
		<h2>User creation failed, please make sure all the boxes are filled out and your class is correct<h2>
		<input type="submit" name="submit_id" id="login" value="Send Me Back To Login" />
	</form>
	</body>
</html>
