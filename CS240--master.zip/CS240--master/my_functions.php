<?php

    if(isset($_GET['method'])){
        if($_GET['method'] === 'logout'){
            destroy_session();
            header("Location: login.php");
        }

    }



    function destroy_session(){
        //unset()
        //session_destroy()
        my_session_start();
        unset($_SESSION['uname']);

        //session_destroy(); //Destroy all data
    }


    function my_session_start(){
        if(session_status()!==PHP_SESSION_ACTIVE){
            session_start();
        }
    }



    ?>